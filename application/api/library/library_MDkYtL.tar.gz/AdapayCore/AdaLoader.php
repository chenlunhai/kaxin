<?php
define("CORE_BASE", dirname(__FILE__));

include_once CORE_BASE."/utils/AdaRequests.php";
include_once CORE_BASE."/utils/AdaTools.php";
include_once CORE_BASE."/utils/AdaSubscribe.php";
include_once CORE_BASE."/vendor/autoload.php";
